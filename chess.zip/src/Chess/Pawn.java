package Chess;

public class Pawn extends Piece {
	
	private Position initialPos;
	private int forward;

	
	
	
	public Pawn(Position _pos, pieceColor _color) {
		super(_pos, _color);
		if(_color == pieceColor.WHITE) forward=-Position.positionUnit;
		if(_color == pieceColor.BLACK) forward=Position.positionUnit;
		initialPos  = new Position(_pos);
		this.sprite = getSpriteGeneral("W_Pawn.png", "B_Pawn.png");
		
	}
	
	public boolean canMove(Tile tile) {
		/*if the pawns 1 diagonal-forward left/right
		to an opposite color piece, they can capture the piece*/
		
		if(Math.abs(tile.getPos().xDiffrent(this.pos))==Position.positionUnit && //the difrences between the axes value is one position units
		/*And*/ tile.getPos().getY() == this.getPos().getY() + forward && //the tile is one tile "forward"
		tile.isOccupied()) //check that there is a opposite color piece there.
		{return true;}
		
			
		
		//first check that there is no one in front of the pawn.
		if(tile.isOccupied()) return false;
			
		//if the pawns in their initial rows they can advance 2 tiles.
		if(this.pos.equals(initialPos) && //if we are at our inital pos.
		/*And*/ tile.getPos().equals(this.pos.getX(), this.pos.getY()+2*forward)) { //if the tile is 2 steps forward on y axis
			return true;
		}
		
		return tile.getPos().equals(this.pos.getX(), this.pos.getY()+ 1*forward);
		
	}

	//getting the sprite of the piece to print it
	
	@Override
	public boolean canCapture(Piece p) {
		return Math.abs(p.getPos().xDiffrent(this.pos))==Position.positionUnit && //the difrences between the axes value is one position units
				/*And*/ p.getPos().getY() == this.getPos().getY() + forward; //the tile is one tile "forward" //check that there is a opposite color piece there.
	}
	
	

	
	
	

}
