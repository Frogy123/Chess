package Chess;
import java.awt.Point;
public class Position {
	
	public static final int positionUnit = 75;
	
	private int x;
	private int y;
	
	public Position(int _x, int _y) {
		//the fifty is for the edeges of the screen
		this.x = _x*positionUnit + 50;
		this.y = _y*positionUnit + 50;
	}
		
	//a constructor that get a Point.
	public Position(Point point) {
		this.x = (int) point.getX();
		this.y = (int) point.getY();
	}
	
	public Position(Position pos) {
		this.x = pos.getX();
		this.y = pos.getY();
	}
	
	//do position equals
	public boolean equals(Position pos) {
		boolean sameX = pos.getX() == this.x;
		boolean sameY = pos.getY() == this.y;
		
		if(sameX && sameY) return true;
		    /*other wise*/ return false; 
	}
	public boolean equals(int x, int y) {
		boolean sameX = x == this.x;
		boolean sameY = y == this.y;
		
		if(sameX && sameY) return true;
		    /*other wise*/ return false; 
	}
	
	//rounding the position to be compatible with the tiles greed
	public void posRoundToTile(){

		int posX = this.x - 50; //removing the space between the screen and the board;
		int posY = this.y - 50; //removing the space between the screen and the board;
		
		//round to the position to the left down corner of the tile pressed.
		this.x = (int) (Math.floor(posX/positionUnit) * positionUnit)+ 50; 
		this.y = (int) (Math.floor(posY/positionUnit) * positionUnit) + 50;
	
	}
	
	//returns the diffrent in the poisiton in y
	public int yDiffrent(Position pos) {
		return Math.abs(this.y - pos.y);
	}
	
	//returns the diffrent in the poisiton in x
	public int xDiffrent(Position pos) {
		return  Math.abs(this.x - pos.x)  ;
	}
	
	public void addDirection(Direction d) {
		
		this.x += d.getXDirection()*positionUnit;
		this.y += d.getYDirection()*positionUnit;
	}
	
	public static Position addDirection(Position pos, Direction d, int times) {
		return new Position(pos.getX()+d.getXDirection()*positionUnit*times,
				            pos.getY()+d.getYDirection()*positionUnit*times);
	}
	
	public static Position addDirection(Position pos, Direction d) {
		return new Position(pos.getX()/positionUnit+d.getXDirection(),
				            pos.getY()/positionUnit+d.getYDirection());
	}
	
	public Position subtractDirection(Direction d) {
		
		this.x -= d.getXDirection()*positionUnit;
		this.y -= d.getYDirection()*positionUnit;
		
		return this;
	}
	
	public boolean isOutOfBoard(){
		if(this.x < 50 || this.x > 575) return true;
		if(this.y < 50 || this.y > 575) return true;
		
		return false;
		
	}
	
	
	
	
	
	
	
	//getters and setters
	public int getX(){
		return x;
	}

	public void setX(int _x) {
		this.x = _x*75 + 50;
	}

	public int getY() {
		return y;
	}

	public void setY(int _y) {
		this.y = _y*75+50;
	}
	//_______________________________
	
	public String toString()
	{
		return "["+ x + "," + y + "]";
	}
	
	

}
