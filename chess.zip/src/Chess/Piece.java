package Chess;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.border.TitledBorder;

public abstract class Piece{
	
	final static String spritePath = "Sprites\\";
	
	Position pos;
	pieceColor color;
	
	BufferedImage sprite;
	
	public static ArrayList<Piece> blackPieces = new ArrayList<Piece>();
	public static ArrayList<Piece> whitePieces = new ArrayList<Piece>();
	
	
	
	
	
	
	public Piece(Position _pos, pieceColor _color) {
		this.pos = _pos;
		this.color = _color;
		if(!(this instanceof Pawn)) {
			if(_color == pieceColor.WHITE) whitePieces.add(this);
			if(_color == pieceColor.BLACK) blackPieces.add(this);
		}
	}
	
//___________getters and setters__________
	public Position getPos() {
		return pos;
	}


	public void setPos(Position pos) {
		this.pos = pos;
	}


	public pieceColor getColor() {
		return color;
	}


	public void setColor(pieceColor color) {
		this.color = color;
	}
	
	public BufferedImage getSprite() {
		return this.sprite;
	}
//_________________________________________
	
	//move releated function:
	//check if the piece can move to a certain tile.
	public abstract boolean canMove(Tile tile);
	
	//move the piece to a certain tile. and return true if the move sucseed and false otherwise.
	public boolean move(Tile tile) {
		
		Tile pastTile = Tile.getTileByPos(this.getPos());
		/*the piece can move, just if the certain piece can move to the tile,
		 *  and the path is clean (in case whare the piece is not a knight)
		 */
		Direction direction = new Direction(this.pos, tile.getPos());
		
		if(this.canMove(tile) && 
		/*AND*/(this instanceof Knight || isPathClean(tile, direction))) {
			
			Piece p = tile.getPiece();
			changeTile(tile);	
			
			King currKing = King.getKingByColor(Gameplay.turn);
		
			//if the new Sitouation give a check to the same turn king, we will not make the move.
			if(ThreatDetector.isKingInThreat(currKing)) {
				if(ThreatDetector.isCheckmate(currKing)) {
					System.out.println("checkMate");
					return false;
				}
				changeTile(pastTile);
				//if we override a piece in the process of tryinh moving, will return the piece
				if(p!=null) tile.setPiece(p);
				return false;
			}
			
			if(tile.isOccupied()) {this.capture(tile); return true;}
		
			Game_Manager.canvas.repaint();
			Gameplay.changeTurn();
			Gameplay.tileChosed = null;
			return true;
			}
		return false;
	}
	
	public void capture(Tile tile) {
		Piece.getPiecesArr(this.getOppositeColor()).remove(tile.getPiece());
		Game_Manager.canvas.repaint();
		Gameplay.changeTurn();
		Gameplay.tileChosed = null;
		Gameplay.check = ThreatDetector.isKingInThreat(King.getKingByColor(Gameplay.turn));
		
		
	}
	

	public void changeTile(Tile moveToTile) {
		
		Tile[][] boardTest = Game_Manager.board;
		
		Tile pastTile = Tile.getTileByPos(this.getPos());
		
		moveToTile.setPiece(this);
		this.pos = moveToTile.getPos();
		
		pastTile.setPiece(null);
		
		
	}
	//_______________________________________
	
	//returning the opposite color of this piece Color
	public pieceColor getOppositeColor() {
		if(this.getColor() == pieceColor.WHITE) return pieceColor.BLACK;
		if(this.getColor() == pieceColor.BLACK) return pieceColor.WHITE;
		
		return null; //just for returning
	}
	
	//getting a tile and a direction from the piece to the tile and returning
	//weather the path is free to go (true) or blocked by other piece.
	public boolean isPathClean(Tile tile, Direction d) {
		Position pos = new Position(this.pos);
		Position tilePos = new Position(tile.getPos());
		
		tilePos.subtractDirection(d); /*we substurct one direction because even if the original tile occupied with 
		another opposite color piece, the piece can 
		still move to this tile and capture the opposite color piece. */
		
		//we going through each tile to check if he is occupied.
		while(!pos.equals(tilePos)) {
			pos.addDirection(d);
			Tile posTile = Tile.getTileByPos(pos);
			if(posTile.isOccupied()) return false;
		}
		return true;
		
	}
	
	//past condition a non null piece.
	//post condition: return true if the current piece can capture p.
	public boolean canCapture(Piece p) {
		Tile tile = p.getTile();
		Direction d = new Direction(this.getPos(), p.getPos());
		return this.canMove(tile) && this.isPathClean(tile, d) && !p.getPos().equals(this.pos);
	}
	
	//past condition a non null tile.
	//post condition: return true if the current piece can capture some piece at tile t.
	public boolean canCapture(Tile t) {
		Position tilePos = new Position(t.getPos());
		Direction d = new Direction(this.getPos(), tilePos);
		return this.canMove(t) && this.isPathClean(t, d) && !tilePos.equals(this.pos);
	}
	//__________________________________________________________________________________________
	
	
	
	//getting the sprite of the Piece
	//general means that every piece will get other function becasue her
	//white and black sprites, arent the same.
	public BufferedImage getSpriteGeneral(String white, String black) {
		//paths of the pieces File
				String blackPath = spritePath + black;
				String WhitePath = spritePath + white;
				BufferedImage img = null;
				File f = null;
				
				//picking the sprite based on the colors
				if(color==pieceColor.WHITE) {
					f = new File(WhitePath);
				}else if(color==pieceColor.BLACK) {
					f = new File(blackPath);
				}
				
				//read the img
				try {
					img = ImageIO.read(f);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				return img;
	}
	
	public Tile getTile() {
		return Tile.getTileByPos(this.pos);
	}
	
	public static ArrayList<Piece> getPiecesArr(pieceColor color){
		if(color == pieceColor.BLACK) return blackPieces;
		if(color == pieceColor.WHITE) return whitePieces;
		
		return null;
	}
	

	//basics rules to 
	
}
