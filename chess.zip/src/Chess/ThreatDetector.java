package Chess;

import java.awt.Color;
import java.security.AllPermission;
import java.util.ArrayList;

public class ThreatDetector {
	King whiteK;
	King blackK;
	
	private static final Direction[] allDirection = Direction.allDirection;
	
	public ThreatDetector(King _whiteK, King _blackK) {
		this.whiteK = _whiteK;
		this.blackK = _blackK;	
	}
	
	
	//past condition: get a piece of type king
	//post condition: return true if the king is threaten in the currect pos (check) or false otherwise.
	public static boolean isKingInThreat(King k) {
		
		int forward = 0; //in which direction the opponent piece are attacking
		
		if(k.getColor() == pieceColor.WHITE) forward=-1;
		if(k.getColor() == pieceColor.BLACK) forward=1;
		
		Position Kingp = new Position(k.getPos());
		
		//treating pawns check by checking each individual square in the current direction forward
		Position pawn1 = new Position(Position.addDirection(k.getPos(), new Direction(-1, forward)));
		Position pawn2 = new Position(Position.addDirection(k.getPos(), new Direction(1, forward)));
		
		
		Tile tile2check1 = Tile.getTileByPos(pawn1);
		Tile tile2check2 = Tile.getTileByPos(pawn2);
		
		if(tile2check1 != null && tile2check1.isOccupied()&& tile2check1.getPiece() instanceof Pawn && tile2check1.getPiece().getColor()== k.getOppositeColor()) return true;
		if(tile2check2 != null && tile2check2.isOccupied()&& tile2check2.getPiece() instanceof Pawn && tile2check2.getPiece().getColor()== k.getOppositeColor()) return true;

		
		//going over the opponenet pieces arraylist and checking if any of the pieces can capture the king.
		ArrayList<Piece> Pieces = Piece.getPiecesArr(k.getOppositeColor());
		for(Piece p: Pieces) {
			if(p.canCapture(k))return true;
		}
		return false;
	}
	
	
	
	public static boolean isTileInThreat(Tile tile, pieceColor oppColor) {
		
		int forward = 0; //in which direction the opponent piece are attacking
	
		if(oppColor == pieceColor.WHITE) forward=1;
		if(oppColor == pieceColor.BLACK) forward=-1;
		
		Position Kingp = new Position(tile.getPos());//al square in the current direction forward
		Position pawn1 = new Position(Position.addDirection(tile.getPos(), new Direction(-1, forward)));
		Position pawn2 = new Position(Position.addDirection(tile.getPos(), new Direction(1, forward)));
		
		
		Tile tile2check1 = Tile.getTileByPos(pawn1);
		Tile tile2check2 = Tile.getTileByPos(pawn2);
		
		
		//treating pawns check by checking each individ
		if(tile2check1 != null && tile2check1.isOccupied()&& tile2check1.getPiece() instanceof Pawn && tile2check1.getPiece().getColor()== oppColor) return true;
		if(tile2check2 != null && tile2check2.isOccupied()&& tile2check2.getPiece() instanceof Pawn && tile2check2.getPiece().getColor()== oppColor) return true;

		
		//going over the opponenet pieces arraylist and checking if any of the pieces can capture the king.
		ArrayList<Piece> Pieces = Piece.getPiecesArr(oppColor);
		for(Piece p: Pieces) {
			if(p.canCapture(tile))return true;
		}
		return false;
	}
	
	//past condition: get a non null king
	//post condition:: return if the certain king is in checkmate
	public static boolean isCheckmate(King k) {
		
		Direction[] allDirection = Direction.allDirection;
		
		
		for(Direction d: allDirection){
			Position OriginalKingPos = new Position(k.getPos());
			OriginalKingPos.addDirection(d);
			Tile newTile = Tile.getTileByPos(OriginalKingPos);
			
			return newTile !=null && !isTileInThreat(newTile, k.getOppositeColor());
		}
		return true;
	}
	
	
	
	
	
	

}
