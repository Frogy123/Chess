package Chess;
;

public class Rook extends Piece {

	public Rook(Position _pos, pieceColor _color) {
		super(_pos, _color);
		this.sprite = getSpriteGeneral("W_Rook.png", "B_Rook.png");
	}

	public boolean canMove(Tile tile) {
		
		if(tile.isPieceInSameColumn(this) //or
		  || tile.isPieceInSameRow(this)) return true;	 
		
		return false;
	}



}
