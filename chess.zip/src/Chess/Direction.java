package Chess;

public class Direction {
	private int xDirection;
	private int yDirection;
	
	public static final Direction[] allDirection = {
	new Direction(0,-1), //up
	new Direction(0,1),//down
	new Direction(1,0), //right
	new Direction(-1,0), //left
	new Direction(1,1),//right down
	new Direction(1,-1),//right up
	new Direction(-1,1),//left down
	new Direction(-1,-1),//left up						
	};
	
	public Direction(Position posFrom, Position posTo) {
		//signum function returning just the sign of the int, -1 for -, +1 for +, and 0 for 0
		xDirection = (int) Math.signum(posTo.getX()-posFrom.getX());
		yDirection = (int) Math.signum(posTo.getY()-posFrom.getY());
	}
	public Direction(int _xDirection, int _yDirection) {
		//signum function returning just the sign of the int, -1 for -, +1 for +, and 0 for 0
		xDirection = (int) Math.signum(_xDirection);
		yDirection = (int) Math.signum(_yDirection);
	}

	public int getXDirection() {
		return xDirection;
	}

	public void setXDirection(int xDirection) {
		this.xDirection = xDirection;
	}

	public int getYDirection() {
		return yDirection;
	}

	public void setYDirection(int yDirection) {
		this.yDirection = yDirection;
	}
	
	public String toString() {
		return "[" + this.xDirection + "," + this.yDirection + ']';
	}
	

}
