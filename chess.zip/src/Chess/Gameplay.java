package Chess;

import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.SwingUtilities;


public class Gameplay implements MouseListener{
	
	public static Tile tileChosed;
	public static pieceColor turn;
	public static boolean check;
	

		
	//the function that will happen 
	@Override
	public void mouseClicked(MouseEvent e) {
		Point point = e.getPoint(); //get the location of the mouse while it was clicked.
		//for testing
		//_____________________
		
		Position mouseClickedPos = new Position(point);
		mouseClickedPos.posRoundToTile(); //round the pressed pos to a tile pose
		Tile tile = Tile.getTileByPos(mouseClickedPos);
		
		System.out.println(tile);
		//click that choosing a tile with a piece
		//chose a piece just if its the piece turn, and just if the tile is not blankS
		if(isTileChooseable(tile)) {
			tileChosed = tile;
		}
		
		//if tile Already chosen, we will move the piece to that tile if the tile is movable.
		if(isTileMovable(tile)) {
			
			tileChosed.getPiece().move(tile);
			//after the move we will set the tile to null again. to encourage other choose.
			tileChosed = null;
			if(check && ThreatDetector.isCheckmate(King.getKingByColor(turn)
					)) System.out.println("checkmate");
			
			
		} 
		
			
	}
	
	//check if certain tile is choosable.
	public boolean isTileChooseable(Tile tile) {
		//chose a piece just if its the piece turn, and just if the tile is not blank
		return tile.isOccupied() && tile.getPiece().getColor() == turn;
	}
	
	//check if tile is *GENRALY* movable
	public boolean isTileMovable(Tile tile) {
		/*we will check first if we have a piece choosed,
		 or opposite site color 
		 and if the piece in the tile choose is a pawn*/  
		
		return tileChosed != null //we chosed a tile with a piece
			   && (tile.isOccupied()==false || !(tile.getPiece().getColor() == turn));
		
	}
	
	
	//change the turn from white to black,
	public static void changeTurn() {
		if(turn == pieceColor.WHITE) turn = pieceColor.BLACK;
		
		else if(turn == pieceColor.BLACK) turn = pieceColor.WHITE;
	}


	//________________________________________________________
	//not using those. as part of MouseListner interface.
	@Override
	public void mousePressed(MouseEvent e) {
		//nothing
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		//do nothing
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		//do nothing
		
	}
	//________________________________________________________	

}
