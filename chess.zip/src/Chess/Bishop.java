package Chess;



public class Bishop extends Piece{

	public Bishop(Position _pos, pieceColor _color) {
		super(_pos, _color);
		this.sprite = getSpriteGeneral("W_Bishop.png", "B_Bishop.png");
	}

	public boolean canMove(Tile tile) {
		return tile.isPieceInSameDiagonal(this) ;
	}


	

}
