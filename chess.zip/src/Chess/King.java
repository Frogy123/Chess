package Chess;



public class King extends Piece{
	
	static King whiteKing = new King(Game_Manager.board[7][4].getPos(), pieceColor.WHITE);
	static King blackKing = new King(Game_Manager.board[0][4].getPos(), pieceColor.BLACK);

	public King(Position _pos, pieceColor _color) {
		super(_pos, _color);
		this.sprite = getSpriteGeneral("W_King.png", "B_King.png");
	}
	
	public boolean canMove(Tile tile) {
		
		int xDiffrent = tile.getPos().xDiffrent(this.pos); 
		int yDiffrent = tile.getPos().yDiffrent(this.pos);

		//if the total distance is bigger then 2 then its not a ligal move.
		if(xDiffrent + yDiffrent > 2*Position.positionUnit) return false;
		
		return xDiffrent==Position.positionUnit
			  /*or*/  ||yDiffrent==Position.positionUnit;
	}
	
	//return the king of the color given
	public static King getKingByColor(pieceColor color) {
		if(color==pieceColor.WHITE) return whiteKing;
		return blackKing;
	}


	

}
