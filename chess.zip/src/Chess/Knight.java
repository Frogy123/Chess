package Chess;

import java.util.ArrayList;

public class Knight extends Piece {
	
	public static ArrayList<Knight> blackKnights = new ArrayList<Knight>();
	public static ArrayList<Knight> whiteKnights = new ArrayList<Knight>();

	public Knight(Position _pos, pieceColor _color) {
		super(_pos, _color);
		this.sprite = getSpriteGeneral("W_Knight.png", "B_Knight.png");
		
		if(this.getColor() == pieceColor.BLACK) blackKnights.add(this);
		if(this.getColor() == pieceColor.WHITE) whiteKnights.add(this);
	}

	public boolean canMove(Tile tile) {
		int xDiffrent = tile.getPos().xDiffrent(this.pos); 
		int yDiffrent = tile.getPos().yDiffrent(this.pos);

		//if the total distance is bigger then 2 then its not a legal move.
		if(xDiffrent + yDiffrent != 3*Position.positionUnit) return false;
		//every axis must have at least 1 movement.
		if(xDiffrent*yDiffrent == 0) return false;
		
		return xDiffrent <= 2*Position.positionUnit
	  /*or*/|| yDiffrent <= 2*Position.positionUnit;
		
	}
	
	@Override
	public boolean canCapture(Piece p) {
		return canMove(p.getTile());
	}
	
	
	public static ArrayList<Knight> getKnightArr(pieceColor color){
		if(color == pieceColor.BLACK) return blackKnights;
		if(color == pieceColor.WHITE) return whiteKnights;
		
		return null;
	}




}
