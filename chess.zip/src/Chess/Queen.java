package Chess;




public class Queen extends Piece{

	public Queen(Position _pos, pieceColor _color) {
		super(_pos, _color);
		this.sprite = getSpriteGeneral("W_Queen.png", "B_Queen.png");
	}

	
	public boolean canMove(Tile tile) {
		boolean stright = tile.isPieceInSameColumn(this) || tile.isPieceInSameRow(this);
		return stright || tile.isPieceInSameDiagonal(this);
	}



	

}
