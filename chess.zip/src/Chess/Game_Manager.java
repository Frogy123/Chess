package Chess;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JFrame;




public class Game_Manager extends Canvas 


{
	
	
	private static final long serialVersionUID = 1L;
	
	
	static Tile[][] board = new Tile[8][8];
	static JFrame frame = new JFrame("board");
	static Canvas canvas = new	Game_Manager();
	static ThreatDetector checkDetector;
	
	
	
	
	
	public static void main(String[] args) {
		
		//____setting the window frame___
		//   
		
		
		//add gameplay listner
		Gameplay gm = new Gameplay();
		canvas.addMouseListener(gm);
		
		start();
		canvas.setBackground(Color.blue);
		canvas.setSize(700, 700);	
		frame.add(canvas);
		frame.pack();		
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		
		
		//_______________________________
				
	}
	
//a function that starts the game.
	public static void start() {
		//setting the board: giving every tile its position.
		for(int i=0; i<8; i++) {
			for(int j=0; j<8; j++) {
				Position pos = new Position(j,i); 
				board[i][j] = new Tile(pos);
				
			}
		}	
		//using reset board to set the pieces to there original place.
		resetBoard();
		Gameplay.turn = pieceColor.WHITE;
		Gameplay.check = false;
		
	}
	
	
	
//a function that set all the pieces to their starting place.
	public static void resetBoard() {
		//________________PAWNS___________________
		//White pawns:
		for(int i=0; i<8; i++) {
			Position pos = board[6][i].getPos();
			Pawn p = new Pawn(pos, pieceColor.WHITE);
			board[6][i].setPiece(p);
		}
		
		//black pawns:
		for(int i=0; i<8; i++) {
			Position pos = board[1][i].getPos();
			Pawn p = new Pawn(pos, pieceColor.BLACK);
			board[1][i].setPiece(p);
		}
		//___________________________________________
		
		//________________Rook__________________________________________
		board[0][0].setPiece(new Rook(board[0][0].getPos(), pieceColor.BLACK));
		board[0][7].setPiece(new Rook(board[0][7].getPos(), pieceColor.BLACK));	
		board[7][0].setPiece(new Rook(board[7][0].getPos(), pieceColor.WHITE));
		board[7][7].setPiece(new Rook(board[7][7].getPos(), pieceColor.WHITE));
		//______________________________________________________________
		
		//________________Knight________________________________________
		board[0][1].setPiece(new Knight(board[0][1].getPos(), pieceColor.BLACK));
		board[0][6].setPiece(new Knight(board[0][6].getPos(), pieceColor.BLACK));	
		board[7][1].setPiece(new Knight(board[7][1].getPos(), pieceColor.WHITE));
		board[7][6].setPiece(new Knight(board[7][6].getPos(), pieceColor.WHITE));
		//______________________________________________________________	
		
		//________________Bishop________________________________________
		board[0][2].setPiece(new Bishop(board[0][2].getPos(), pieceColor.BLACK));
		board[0][5].setPiece(new Bishop(board[0][5].getPos(), pieceColor.BLACK));	
		board[7][2].setPiece(new Bishop(board[7][2].getPos(), pieceColor.WHITE));
		board[7][5].setPiece(new Bishop(board[7][5].getPos(), pieceColor.WHITE));
		//______________________________________________________________
		
		//________________King_________________________________________
		
		board[0][4].setPiece(King.blackKing);	
		board[7][4].setPiece(King.whiteKing);
		
		//______________________________________________________________
		
		//________________Queen_________________________________________
		board[0][3].setPiece(new Queen(board[0][3].getPos(), pieceColor.BLACK));	
		board[7][3].setPiece(new Queen(board[7][3].getPos(), pieceColor.WHITE));
		//______________________________________________________________
		
		
	}

//a function of canvas class that paints the objects.
	public void paint(Graphics g) {		
		drawingBoard(g);
		drawingPieces(g);
	}
	
//a function that drawing the board
	public void drawingBoard(Graphics g){
		g.fillRect(50, 50, 600, 600);
		g.setColor(Color.white);
		for(int x=50; x<=600; x+=150){
			for(int y=50; y<=600; y+=150){
				g.fillRect(x, y, 75, 75);
			}
		}
		for(int x=125; x<=600; x+=150){
			for(int y=125; y<=600; y+=150){
				g.fillRect(x, y, 75, 75);
			}
		}
		
	}
//a function that drawing the pieces based on their place on the board.
	public void drawingPieces(Graphics g) {
		
		for(int i=0; i<8; i++) {
			for(int j=0; j<8; j++) {
				if(board[i][j].isOccupied()==true) {
					Piece p = board[i][j].getPiece();
					int xPos = board[i][j].getPos().getX();
					int yPos = board[i][j].getPos().getY();
					g.drawImage(p.getSprite(),xPos, yPos, null);
				}
			}
		}
		
	}
	
}
