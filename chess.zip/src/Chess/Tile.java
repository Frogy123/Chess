package Chess;

public class Tile {
	
	private Position pos;
	private Piece piece;
	
	public Tile(Position pos, Piece piece) {
		this.pos = pos;
		this.piece = piece;
	}
	
	public Tile(Position pos) {
		this.pos = pos;
		this.piece = null;
	}
	
	public boolean isOccupied() {
		return !(piece==null); //return if there is no piece.
	}

	public static Tile getTileByPos(Position pos) { //get the tile on the board by a giving pos.
		
		if(pos.isOutOfBoard()) return null;
		
		int posX = pos.getX() -50;
		int posY = pos.getY() -50;
		
		return Game_Manager.board[posY/Position.positionUnit][posX/Position.positionUnit];
		
		
	}
	
	
	public Position getPos() {
		return pos;
	}

	public void setPos(Position pos) {
		this.pos = pos;
	}

	public Piece getPiece() {
		return piece;
	}

	public void setPiece(Piece piece) {
		this.piece = piece;
	}
	
	public String toString() {
		String str = "Tile in pos: " +  "[" + pos.getX() + "," + pos.getY() + "]" ;//+
		if(this.isOccupied()) str+= "\nWith " + piece.getColor() + " " + piece.getClass();
		
		return str;
	}
	
	
	
	//common and general check for a tile
	
	//same column:
	public boolean isPieceInSameColumn(Piece p)
		{return p.getPos().getX() == this.pos.getX();}
	
	public boolean isTileInSameColumn(Tile tile)
		{return tile.getPos().getX() == this.pos.getX();}
	
	//same row:
	public boolean isPieceInSameRow(Piece p)
		{return p.getPos().getY() == this.pos.getY();}
		
	public boolean isTileInSameRow(Tile tile)
		{return tile.getPos().getY() == this.pos.getY();}
	
	//same diagonal
	public boolean isPieceInSameDiagonal(Piece p)
	{
		int yDiffrent = Math.abs(p.getPos().yDiffrent(this.getPos()));
		int xDiffrent = Math.abs(p.getPos().xDiffrent(this.getPos()));	
		return   yDiffrent == xDiffrent;
	}
	
	public boolean isTileInSameDiagonal(Tile tile)
	{ 
		int yDiffrent = tile.getPos().yDiffrent(this.getPos());
		int xDiffrent = tile.getPos().xDiffrent(this.getPos());	
		return   yDiffrent == xDiffrent;
	}

	

}


