package Chess;

public enum pieceColor {
	WHITE, BLACK;

}
